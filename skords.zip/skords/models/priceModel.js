const mongoose = require('mongoose');

var priceSchema = new mongoose.Schema({
    coin:{
        type:String
    },
    price:{
        type:Number
    },
    currency:{
        type: String,
        default: 'USDT',
        enum: ['USDT']
    },
    addedon:{
        type: Date,
        default: Date.now
    }
});

var priceModel = mongoose.model('bitcoinprices',priceSchema);

module.exports = priceModel;