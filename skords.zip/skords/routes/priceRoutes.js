const express = require('express');
const priceController = require('../controllers/priceController');
const authController = require('../controllers/authController');

const router = express.Router();
router.use(authController.protect);
router.route('/latest-price').get(priceController.getLatestOne);

module.exports = router;