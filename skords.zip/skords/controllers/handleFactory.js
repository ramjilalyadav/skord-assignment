const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const APIFeatures = require('../utils/apiFeatures');


exports.getLatest = (Model,sortby={},project={},skip=0,limit=10) =>{
    catchAsync(async (req, res, next) => {

      let query = [];
      if(sortby){
        query.push({'$sort':{sortby}});
      }
      if(project){
        query.push({'$project':{project}});
      }
      if(skip){
        query.push({'$skip':skip});
      }
      if(limit){
        query.push({'$limit':limit});
      }
      console.log(query);
      const doc = await Model.aggregate(query);
  
      if (!doc) {
        return next(new AppError('No document found', 404));
      }
  
      res.status(200).json({
        status: 'success',
        data: {
          data: doc
        }
      });
    });
  }
  