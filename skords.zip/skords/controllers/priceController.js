const redis = require("redis");
const price = require('../models/priceModel');
const AppError = require('./../utils/appError');


let redisClient;

(async () => {
  redisClient = redis.createClient();

  redisClient.on("error", (error) => console.error(`Error : ${error}`));

  await redisClient.connect();
})();



var createRecord = async (body)=>{
    try{
        const doc = await price.create(body);
        return doc;
    }
    catch(err){
        console.log(err);
    }    
}

async function fetchApiData(req,res,next) {
    let query = [];
    var sortby = {'addedon':-1};
    var skip = 0;
    var limit = 1;
    var project = {'price':1,'addedon':{ '$toLong': '$addedon' }};
    if(sortby){
      query.push({'$sort':sortby});
    }
    if(project){
      query.push({'$project':project});
    }
    if(skip){
      query.push({'$skip':skip});
    }
    if(limit){
      query.push({'$limit':limit});
    }
    
    const doc = await price.aggregate(query);
    if (!doc) {
      return next(new AppError('No document found', 404));
    }
    return {price:doc[0]['price'],timeAt:doc[0]['addedon']};
}


var getLatestOne = async(req,res,next) =>{
    const coin = 'bitcoin';
    let results;
    let isCached = false;
  
    try {
      const cacheResults = await redisClient.get(coin);
      
      if (cacheResults) {
        results = JSON.parse(cacheResults);
        currentTime = Date.now();
        //const date = new Date(results['timeAt']);
        const redisStoredTime = results['timeAt'];
        var timeDiff =  (currentTime-redisStoredTime)/(60 * 1000);
        if(timeDiff>=5){
            results = await fetchApiData();
            await redisClient.set(coin, JSON.stringify(results),{
                EX: 300,
                NX: false,
              });
        }
        else{
            isCached = true;
        }
      } else {

        results = await fetchApiData(req,res,next);
        await redisClient.set(coin, JSON.stringify(results),{
            EX: 300,
            NX: false,
          });
      }
  
      res.send({
        fromCache: isCached,
        data: results,
      });
    } catch (error) {
      console.error(error);
        res.status(404).send("Data unavailable");
    }
}




exports.getLatestOne = getLatestOne;
exports.createRecord = createRecord;
