const express = require('express');
const cron = require('./cli/priceCron');
const priceRouter = require('./routes/priceRoutes');
const authRouter = require('./routes/authRoutes');

const app = express();

app.use(express.json());
cron.start();

app.use('/api/v1/prices', priceRouter);
app.use('/api/v1/auth',authRouter);

module.exports = app;