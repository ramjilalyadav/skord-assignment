const cron = require("node-cron");
const axios = require('axios');
const {createRecord} = require('../controllers/priceController');

const getBitCoinPrice = async () => {
    try {
        const response = await axios.get('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT');
        var record = createRecord(response.data);
        record.then((doc)=>{
            return true;
        });
    } catch (errors) {
      console.error(errors);
    }
};

var crontask = cron.schedule("*/5 * * * *", getBitCoinPrice,{scheduled: false});
module.exports = crontask;
  